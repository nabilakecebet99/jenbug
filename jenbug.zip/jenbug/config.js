require("./database/module")

//GLOBAL PAYMENT
global.storename = "ZennStore"
global.dana = "6289699340701"
global.qris = '-'


// GLOBAL SETTING
global.owner = "6289699340701" //masukin no lu
global.namabot = "Zenn-Botzz"
global.nomorbot = "62838997622968" //masukin no lu
global.namaCreator = "Zenn"
global.linkyt = "https://youtube.com/@zynxzoo"
global.autoJoin = false
global.antilink = false
global.versisc = '𝟭𝟮.𝟬.𝟬'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com'
global.eggsnya = '15'
global.location = '1'



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://telegra.ph/file/268fa9d0c1314506c99df.jpg'
global.isLink = 'https://whatsapp.com/channel/0029VapVjjr1noz8wOgd6144'
global.packname = "Zenn"
global.author = "Zenn"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})